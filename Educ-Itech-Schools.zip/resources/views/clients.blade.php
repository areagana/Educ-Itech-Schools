@Extends('layouts.home')
@section('homeContent')
    <div class="container">
        Clients
    </div>
@endsection