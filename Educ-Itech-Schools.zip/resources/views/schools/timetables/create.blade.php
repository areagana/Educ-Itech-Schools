@Extends('schools.details')
@section('crumbs')

@endsection
@section('schoolContent')
    <div class="row p-2">
        <div class="col p-2">
            <div class="header h3">Time tables</div>
            <div class="p-2">
                create timetables here
            </div>
        </div>
    </div>
@endsection