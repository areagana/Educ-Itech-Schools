@Extends('layouts.home')
@section('homeContent')
    <div class="container">
        services
    </div>
@endsection