
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2">
        <div class="p-2 bg-white">
            <div class="card p-2 border-primary">
                <h5 class="p-2 border-bottom border-primary">Subjects
                    <span class="right inline-block"> 
                        <input type="text" class="form-control form-control-sm" placeholder='Search...' id='searchSubject' onkeyup="SearchItem('searchSubject','school-subjects','tr')">
                    </span>
                </h5>
                <span class="text-muted"></span>
                <table class="table table-sm">
                    <thead class="table-info">
                        <tr>
                            <th>#</th>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th>Subject Term</th>
                            <th>Users</th>
                            <th>More</th>
                        </tr>
                    </thead>
                    <tbody id='school-subjects'>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($subject->subject_code); ?></td>
                                <td><?php echo e($subject->subject_name); ?></td>
                                <td><?php echo e($subject->term->term_name); ?></td>
                                <td><?php echo e($subject->users->count()); ?></td>
                                <td>
                                    <?php if($subject->term === $term): ?>
                                    <span class="inline-block">
                                        <a href="<?php echo e(route('SubjectEnroll',$subject->id)); ?>" class="nav-link btn btn-sm btn-light btn-circle"  data-tippy="Add Users" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><i class="fa fa-plus"></i></a>
                                        <a href="<?php echo e(route('subjectMembers',$subject->id)); ?>" class="nav-link btn btn-sm btn-light btn-circle"  data-tippy="View List" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><i class="fa fa-eye"></i></a>
                                    </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                        
                    </tbody>
                </table>
            </div>
            <div class="row p-1">
                <div class="col p-2">
                    <?php echo e($subjects->links()); ?>

                </div>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/index.blade.php ENDPATH**/ ?>