
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schoolView',$school,$school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <a href="" class="nav-link">Dashbboard</a>
            </div>
        </div>
        <div class="row p-2">
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Courses</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('course.jpg')); ?>" alt="" class='img-sm img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <span class="p-4 h3">
                        <?php echo e($school->courses->count()); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Subjects</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('subject-icon.png')); ?>" alt="" class='img-sm img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <?php if($term): ?>
                            <span class="p-4 h3">
                            <?php echo e($term->subjects->count()); ?>

                            </span>
                        <?php else: ?>
                        <span class="h3 p-4"><?php echo e(__(0)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Users</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('student icon.png')); ?>" alt="" class='img-sm img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <span class="p-4 h3">
                        <?php echo e($school->users->count()); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row p-2">
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Exams</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('exams-icon.png')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <?php if($term): ?>
                            <span class="p-4 h3">
                                <?php echo e($term->exams->count()); ?>

                            </span>
                        <?php else: ?>
                        <span class="h3 p-4"><?php echo e(__(0)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Assignments</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('assignment-icon.png')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <?php if($term): ?>
                            <span class="p-4 h3">
                            <?php echo e($term->assignments->count()); ?>

                            </span>
                        <?php else: ?>
                        <span class="h3 p-4"><?php echo e(__(0)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Notices</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('notice-icon.jpg')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <span class="p-4 h3">
                        <?php echo e($school->announcements->count()); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row p-2">
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Exams</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('exams-icon.png')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <?php if($term): ?>
                            <span class="p-4 h3">
                                <?php echo e($term->exams->count()); ?>

                            </span>
                        <?php else: ?>
                        <span class="p-4 h3"><?php echo e(__(0)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Assignments</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('assignment-icon.png')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <?php if($term): ?>
                            <span class="p-4 h3">
                            <?php echo e($term->assignments->count()); ?>

                            </span>
                        <?php else: ?>
                            <span class="p-4 h3"><?php echo e(__(0)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-3 bg-white shadow-sm dash-card mx-1">
                <h4>Notices</h4>
                <div class="row p-2">
                    <div class="col p-2">
                        <img src="<?php echo e(asset('notice-icon.jpg')); ?>" alt="" class='img-sm rounded-circle'>
                    </div>
                    <div class="col p-2 border-left">
                        <span class="p-4 h3">
                        <?php echo e($school->announcements->count()); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/home.blade.php ENDPATH**/ ?>