
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schoolView',$school,$school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('schoolContent'); ?>
<!-- school term name-->
<?php if(!$term): ?>
<!-- term notification-->
<div class="term-notice shadow bg-white p-2 justify-content-center row absolute">
    <div class="col p-2 notice-info">
        <h4 class="header"><i><b>Notice</b></i></h4>
        <?php if(!$term): ?>
            <span>
                No term has been set for your school. Please contact the school administrator to have a school term setup. <br>
                Thank You. <br>
            </span>
        <?php endif; ?>
    </div>
    <div class="col-md-2 p-2 border-left">
        <button class="btn btn-light btn-sm right" onclick="Close('term-notice')"  data-tippy="Close" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward">&times;</button>
    </div>
</div>
<?php endif; ?>
<!--end term notification-->
<div class="container-fluid">
    <?php echo $__env->yieldContent('details'); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/details.blade.php ENDPATH**/ ?>