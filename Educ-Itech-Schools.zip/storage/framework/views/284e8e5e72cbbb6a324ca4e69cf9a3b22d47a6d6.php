
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjectConferences',$subject,$subject->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <div class="row p-1">
            <div class="col p-2">
                <h3 class="header">Conferences</h3>
            </div>
        </div>
        <div class="row p-1">
            <div class="col p-2">
<!-- new conferences-->
                <div class="accordion m-3" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h4 class="mb-0">
                                <span  data-toggle="collapse" data-target="#collapsenew" aria-expanded="true" aria-controls="collapseOne">
                                    NEW CONFERENCES
                                </span>
                                <?php if(Auth::user()->hasRole(['teacher'])): ?>
                                <span class="right">
                                    <button class="btn btn-secondary btn-sm" data-toggle='modal' data-target='#new-conference'><i class="fa fa-plus"> Conference</i></button>
                                </span>
                                <?php endif; ?>
                            </h4>
                        </div>
                        <div id="collapsenew" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <?php if($conferences): ?>
                                <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-2 row border border-info">
                                            <div class="col p-1">
                                                <?php echo e($conference->conference_name); ?>

                                                <span class="right">
                                                    <?php if($conference->user == Auth::user()): ?>
                                                        <a href="<?php echo e($conference->conference_link); ?>" class="nav-link"><button class="btn btn-sm btn-primary">Start</button></a>
                                                    <?php else: ?> if(Auth::user()->hasRole('student'))
                                                    <a href="<?php echo e($conference->conference_link); ?>" class="nav-link"><button class="btn btn-sm btn-success">Join</button></a>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- Button trigger modal -->
                <!-- Modal -->
                <div class="modal fade" id="new-conference" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($subject->subject_name); ?> New Conference</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="p-2">
                            <form action="<?php echo e(route('newConference')); ?>" id="new-conference-form" method='POST'>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                    <label for="conference_title" class="form-label">Title</label>
                                    <input type="text" name="conference_title" id="conference_title" value="<?php echo e($subject->subject_code); ?> - Conference" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="conference_duration" class="form-label">Duration (minutes)</label>
                                    <input type="text" name="conference_duration" id="conference_duration" value='60' class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="unlimited_time" id="unlimited_time" value='unlimited'>
                                    <label for="unlimited_time" class="form-label">Unlimited Time</label>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="enable_recording" id="conference_recording" value='True'>
                                    <label for="conference_recording" class="form-label">Enable Recording</label>
                                </div>
                                <div class="form-group">
                                    <label for="conference_details" class="form-label">Description</label>
                                    <textarea type="text" name="conference_details" id="conference_details" class="form-control" required></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="conference_link" class="form-label">Link</label>
                                    <input type="text" name="conference_link" id="conference_link"  class="form-control" placeholder="Paste link...">
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                        <button  class="btn btn-primary btn-sm" type='submit' form="new-conference-form">Save</button>
                    </div>
                    </div>
                </div>
                </div>

<!--concluded conferences-->
                <div class="accordion m-3" id="accordionEnded">
                    <div class="card">
                        <div class="card-header" id="headingEnded">
                            <h4 class="mb-0">
                                <span  data-toggle="collapse" data-target="#collapseEnded" aria-expanded="true" aria-controls="collapseOne">
                                    CONCLUDED CONFERENCES
                                </span>
                            </h4>
                        </div>
                        <div id="collapseEnded" class="collapse show" aria-labelledby="headingEnded" data-parent="#accordionEnded">
                        <div class="card-body">
                            <?php if(!empty($conferences)): ?>
                                <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-2 row">
                                            <div class="col p-1">
                                                <?php echo e($conference->conference_name); ?>

                                            </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/conferences/index.blade.php ENDPATH**/ ?>