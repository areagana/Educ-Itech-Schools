<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
       <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'EDUC-ITECH')); ?></title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>



        <!--xdialog javascript-->
        <script src="<?php echo e(asset('js/xdialog.3.4.0.min.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/xdialog.3.4.0.min.css')); ?>" rel="stylesheet">
        <?php echo $__env->make('popper::assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <?php if(auth()->guard()->check()): ?>
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-info">
                    <img src="" alt="" class='nav-logo bg-white m-1'>
                    <?php echo e(config('app.name', 'EDUC-ITECH')); ?>

                </div>
                <div class="list-group list-group-flush">
                <?php if(Auth::user()): ?>
                    <?php if(Auth::user()->hasRole(['superadministrator','administrator','manager'])): ?>
                        <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(route('home')); ?>">Dashboard</a>
                    <?php endif; ?>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(route('schools')); ?>">Schools</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="">Classe</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="">Subjects</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#expenses-more" data-toggle="collapse">Users</a>
                    <ul class='collapse' id="expenses-more">
                        <a href="" class="list-group-item list-group-item-action list-group-item-light p-3">Leaders</a>
                        <a href="" class="list-group-item list-group-item-action list-group-item-light p-3">Teachers</a>
                    </ul>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="">Reports</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="">Settings</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#logout" data-toggle="collapse"><?php echo e(Auth::user()->firstName); ?></a>
                    <ul class='collapse' id="logout">
                        <a class="list-group-item list-group-item-action list-group-item-light p-3 text-danger h3" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </ul>
                <?php endif; ?>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg  navbar-fixed-top navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <i class="fa fa-bars p-2 hide-left-nav btn btn-light h3" id="sidebarToggle"></i>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        
                        <?php if(auth()->guard()->check()): ?>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->firstName); ?></a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#!">Profile</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid mt-4">
                        <?php if(session('success')): ?>
                            <div class="bg-white success shadow">
                                <h4 class="header bg-light p-3">
                                    MESSAGE
                                    <span class="right">
                                        <button class="btn btn-danger btn-sm close-session-msg" onclick="closeParent3()">&times;</button>
                                    </span>
                                </h4>
                                <div class="p-3 h4">
                                    
                                    <?php echo e(session('success')); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('crumbs'); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="//cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace('assignment_content' );
            CKEDITOR.replace('textarea');
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\layouts\app.blade.php ENDPATH**/ ?>