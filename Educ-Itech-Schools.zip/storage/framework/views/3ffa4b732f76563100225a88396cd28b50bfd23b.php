
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjectMember',$subject,$subject->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
<div class="container-fluid">
    <div class="h3 header">Members</div>
    <div class="row p-2">
        <div class="col-md-4 p-2">
            <select name="" id="filter-subject-members" class="custom-select" onchange="FilterMembers('filter-subject-members',<?php echo e($subject->id); ?>)">
                <option value="All">All</option>
                <option value="student">Students</option>
                <option value="teacher">Teachers</option>
            </select>
        </div>
        <div class="col p-2">
            <input type="text" class="form-control" id="search-member" onkeyup="SearchItem('search-member','subject-people','tr')" placeholder='Search...'>
        </div>
    </div>
    <div class="row p-1">
        <div class="col p-2">
            <table class="table table-sm">
                <thead class="table-info">
                    <tr>
                        <th>user_id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody id="subject-people">
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($member->id); ?></td>
                            <td>
                                <a href="" class="nav-link"><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></a>
                            </td>
                            <td><?php echo e($member->email); ?></td>
                            <td>
                                <?php if($member->hasRole('student')): ?>
                                    <?php echo e(__('Student')); ?>

                                <?php elseif($member->hasRole('teacher')): ?>
                                    <?php echo e(__('Teacher')); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(Auth::user()->isAbleTo('user-edit')): ?>
                                    <i class="fa fa-edit"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\subjects\people\index.blade.php ENDPATH**/ ?>