
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <div class="card p-2">
                    <h4 class="border-bottom border-primary">
                        <?php echo e($school->school_name); ?> / Teachers
                        <span class="right">
                            <input type="text" class='form-control form-control-sm' id="searchTeacher" onkeyup="SearchItem('searchTeacher','school-teachers','tr')" placeholder='Search...'>
                        </span>
                    </h4>
                    <table class="table table-sm">
                        <thead class="table-info">
                            <tr>
                                <th>Teacher Id</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id='school-teachers'>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($teacher->id); ?></td>
                                    <td><?php echo e($teacher->firstName); ?></td>
                                    <td><?php echo e($teacher->lastName); ?></td>
                                    <td><?php echo e($teacher->email); ?></td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($teachers->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\teachers\index.blade.php ENDPATH**/ ?>