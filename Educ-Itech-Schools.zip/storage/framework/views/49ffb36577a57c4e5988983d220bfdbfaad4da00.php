
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schoolEdit',$school,$school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row p-2">
        <div class="col p-2 bg-white shadow-sm">
            <h5 class="header"><?php echo e($school->school_name); ?></h5>
                <form action="<?php echo e(route('SchoolUpdate')); ?>" method='POST' id='school-edit-form'>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name='school_id' value="<?php echo e($school->id); ?>">
                        <label for="school_name" class="form-label">School Name</label>
                        <input type="text" class="custom-input" name='school_name' value="<?php echo e($school->school_name); ?>" id='school_name'>
                    </div>
                    <div class="form-group">
                        <label for="school_code" class="form-label">School Code</label>
                        <input type="text" class="custom-input" name='school_code' value="<?php echo e($school->school_code); ?>" id='school_code'>
                    </div>
                    <div class="form-group">
                        <label for="school_reg_no" class="form-label">School Reg No</label>
                        <input type="text" class="custom-input" name='school_reg_no' value="<?php echo e($school->reg_no); ?>" id='school_reg_no'>
                    </div>
                    <div class="form-group">
                        <label for="school_address" class="form-label">School Address</label>
                        <input type="text" class="custom-input" name='school_address'  value="<?php echo e($school->address); ?>" id='school_address'>
                    </div>
                    <div class="form-group">
                        <label for="school_email" class="form-label">School Email</label>
                        <input type="text" class="custom-input" name='school_email' value="<?php echo e($school->email); ?>" id='school_email'>
                    </div><div class="form-group">
                        <label for="school_contact" class="form-label">School Contact</label>
                        <input type="text" class="custom-input" name='school_contact' value="<?php echo e($school->contact); ?>" id='school_contact'>
                    </div><div class="form-group">
                        <label for="school_website" class="form-label">School Website</label>
                        <input type="text" class="custom-input" name='school_website_link' value="<?php echo e($school->website); ?>" id='school_website'>
                    </div>
                </form>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-sm btn-danger" onclick="Close('new-school')">Cancel</button>
                        <button class="btn btn-sm btn-primary right" type='submit' form='school-edit-form'>Update</button>
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\schools\edit.blade.php ENDPATH**/ ?>