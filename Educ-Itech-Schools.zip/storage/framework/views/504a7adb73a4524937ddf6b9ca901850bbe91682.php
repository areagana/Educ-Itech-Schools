
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subject',$subject,Auth::user()->school,Auth::user()->school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 p-1">
                <ul class="nav">
                    <li class="nav-item">
                        <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">Home</a>
                        <a href="" class="nav-link">Notes</a>
                        <a href="<?php echo e(route('assignments',$subject->id)); ?>" class="nav-link">Assignments</a>
                        <a href="<?php echo e(route('subjectGrades',$subject->id)); ?>" class="nav-link">Grades</a>
                        <a href="<?php echo e(route('subjectConferences',$subject->id)); ?>" class="nav-link">Conferences</a>
                        <a href="<?php echo e(route('subjectAnnouncements',$subject->id)); ?>" class="nav-link">Announcements</a>
                        <a href="<?php echo e(route('subjectMember',$subject->id)); ?>" class="nav-link">Members</a>
                        <a href="<?php echo e(route('subjectFiles',$subject->id)); ?>" class="nav-link">Files</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-10">
                <?php echo $__env->yieldContent('subjectContent'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\layouts\subjectview.blade.php ENDPATH**/ ?>