
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2 bg-white">
            <div class="col p-2">
                <div class="card p-2 border border-primary">
                    <h5 class="header">FILTER STUDENTS BY CLASS
                        <span class="right">
                            <input type="text" class="form-control form-control-sm" id='student-search' placeholder="Search student...">
                        </span>
                    </h5>
                    <span class="inline-block">
                        Class Code:
                        <?php $__currentLoopData = $school->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a  class="nav-link" onclick="LocateStudents(<?php echo e($school->id); ?>,<?php echo e($form->id); ?>)"><?php echo e($form->form_name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="row p-2 bg-white mt-2">
            <div class="col p-2">
                <div class="card border border-primary p-2">
                    <div class="form-student-title border-bottom border-primary h4 hidden"></div>
                    <table class="table table-sm">
                        <thead class="table-info" id='student-table-thead'>
                            <tr>
                                <th>
                                    <input type="checkbox" name="school_student[]" id="check_all">
                                </th>
                                <th>User Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <?php if(Auth::user()->isAbleTo(['users-edit','users-delete','users-update'])): ?>
                                <th>More</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody id="school-students">
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="school_student[]" id="<?php echo e($school->school_code); ?><?php echo e($student->id); ?>">
                                    </td>
                                    <td><?php echo e($student->id); ?></td>
                                    <td><?php echo e($student->firstName); ?>, <?php echo e($student->lastName); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td>
                                        <?php if($student->hasRole('student')): ?>
                                        <?php echo e(__('Student')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(Auth::user()->isAbleTo(['users-edit','users-delete','users-update'])): ?>
                                    <td>
                                        <div class="span inline-block">
                                            <a href="#" class="nav-link btn btn-circle btn-sm btn-white"><i class="fa fa-edit"></i></a>
                                            <a href="#" class="nav-link btn btn-circle btn-sm btn-white"><i class="fa fa-trash"></i></a>
                                            <a href="#" class="nav-link btn btn-sm btn-white btn-circle right"><i class="fa fa-ellipsis-v"></i></a>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="row p-2">
                        <div class="col p-2 pagination">

                        </div>
                    </div>
                </div>
            </div>
            <?php echo e($students->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\students\index.blade.php ENDPATH**/ ?>