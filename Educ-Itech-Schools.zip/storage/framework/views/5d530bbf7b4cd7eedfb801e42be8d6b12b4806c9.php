
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <h3>DASHBOARD</h3>
            </div>
        </div>
        <!--generate user subjects-->
        <div class="row p-2">
            <div class="col">
                <div class="p-2 inline-block">
                    <?php $__currentLoopData = Auth::user()->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 subject-card shadow-sm bg-white justify-content-center m-2">
                        <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">
                            <div class="p-2">
                                <div class="p-2 justify-content-center">
                                    <h3><?php echo e($subject->subject_name); ?>

                                        
                                    </h3>
                                    <h6 class="text-muted">
                                        <?php echo e($subject->form->form_name); ?>

                                    </h6>
                                </div>
                                <div class="p-2">
                                    <?php echo e($subject->subject_code); ?>  
                                </div>
                            </div>
                        </a>
                        <div class="row p-2">
                            <div class="col p-2 border-top">
                            <span class="right">
                                <i class="fa fa-ellipsis-v btn btn-sm btn-circle btn-light ellipsis"></i>
                            </span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-2 p-2">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\dashboard\index.blade.php ENDPATH**/ ?>