
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('assignments',$subject,$school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <div class="row p-1 bg-white">
            <div class="col p-1">
                <div class="h4 border-bottom">Assignments</div>
            </div>
        </div>
        <div class="row p-1 mt-1">
            <div class="col p-2 bg-white">
                    <div class="accordion m-3" id="accordionAssignment">
                        <div class="card">
                            <div class="card-header" id="headingAssignment">
                                <h4 class="mb-0">
                                    <span  data-toggle="collapse" data-target="#collapseAssignment" aria-expanded="true" aria-controls="collapseOne">
                                        ASSIGNMENTS
                                    </span>
                                    <?php if(Auth::user()->isAbleTo('assignment-create')): ?>
                                    <span class="right h6">
                                        <a href="<?php echo e(route('CreateAssignments',$subject->id)); ?>" class="nav-link bg-secondary text-white"><i class="fa fa-plus"></i> Create</a>
                                    <?php endif; ?>
                                </h4>
                            </div>
                            <div id="collapseAssignment" class="collapse show" aria-labelledby="headingAssignment" data-parent="#accordionAssignment">
                                <div class="card-body">
                                <?php if(count($assignments) >= 1): ?>
                                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('assignment.show',[$subject->id,$assignment->id])); ?>" class="nav-link draggable" ondragstart='' ondragend="">
                                        <div class="p-2 border row assignment bg-white" >
                                            <div class="col-md-1 inline-block border-right">
                                                <i class="fa fa-ellipsis-v"></i>
                                                <i class="fa fa-ellipsis-v"></i>
                                            </div>
                                            <div class="col">
                                                <?php echo e($assignment->assignment_name); ?>

                                                    <span class="right text-muted">
                                                        Due: <?php echo e(dateFormat($assignment->end_date,'D jS M Y')); ?>

                                                    </span>
                                                <div class="p-1 text-muted assignment-state">
                                                    <?php if($assignment->close_date >= date('Y-m-d')): ?>
                                                        Deadline: <?php echo e(dateFormat($assignment->close_date,'D jS M Y')); ?> at <?php echo e(dateFormat($assignment->close_date,'H:m')); ?>Hrs
                                                    <?php else: ?>
                                                        closed on <?php echo e($assignment->close_date); ?>

                                                    <?php endif; ?>
                                                    <span class="right text-muted">
                                                        <?php if(count($assignment->assignment_submissions)>0): ?>
                                                            <?php echo e(count($assignment->assignment_submissions)); ?> Submitted
                                                        <?php else: ?>
                                                            No Submissions
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="col p-2">
                                        <h3>No Assignments Created</h3>
                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="col-md-3 p-2 bg-white ml-2">
                <div class="h5 border-bottom">Upcoming</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/assignments/index.blade.php ENDPATH**/ ?>