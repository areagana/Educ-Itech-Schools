
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjectGrades',$subject,$subject->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
<div class="row mx-1">
    <div class="col p-2 bg-white">
        <h4 class="header"><?php echo e($subject->subject_name); ?> Grades
            <span class="right">
                <button class="btn btn-danger btn-sm" onclick="printPage('user-grades')"><i class="fa fa-print"></i> Print Grades</button>
            </span>
        </h4>
        <div class="p-0" id='user-grades'>
            <table class="table table-sm">
                <thead class="table-info">
                    <tr>
                        <th colspan='6'> <?php echo e($subject->subject_name); ?> Grades for <?php echo e(Auth::user()->firstName); ?> <?php echo e(Auth::user()->lastName); ?></th>
                    </tr>
                    <tr>
                        <th>Assignment Name</th>
                        <th>Close Date</th>
                        <th>Marks</th>
                        <th>Total</th>
                        <th>Comment</th>
                    </tr>
                </thead>
                <tbody id="subject-grade">
                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $submission = $assignment->assignment_submissions()->where('user_id',Auth::user()->id)->get();
                        ?>
                        <tr>
                            <td><?php echo e($assignment->assignment_name); ?></td>
                            <td><?php echo e(dateFormat($assignment->close_date,'M jS H:m')); ?></td>
                            <td>
                            <?php if($submission->count() > 0): ?>
                                    <?php $__currentLoopData = $submission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($sub->submitted_grade); ?>

                                        (<?php echo e($sub->submitted_grade/$assignment->total_points *100); ?>%)
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <span class="text-danger"><?php echo e(__('*not submitted')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($assignment->total_points); ?></td>
                            <td></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><b>Total</b></td>
                        <td></td>
                        <td><b><?php echo e($total_marks); ?> (<?php echo e(number_format($total_marks/$total_points *100,0)); ?>%)</b></td>
                        <td><b><?php echo e($total_points); ?></b></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/grades/studentGrade.blade.php ENDPATH**/ ?>