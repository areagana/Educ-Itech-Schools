
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row p-2">
            <div class="col p-2">
                <div class="header">Bar Code</div>
                <div class="barcodeCode">
                    <div><?php echo DNS1D::getBarcodeHTML('44456', 'UPCA'); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/barcode.blade.php ENDPATH**/ ?>