
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('gradeAssignment',$subject,$assignment,$subject->id,$assignment->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2 bg-white mt-1">
            <div class="col p-1">
                <ul class="nav">                            
                    <li class="nav-item">
                        <span class="h5">
                            <a href="<?php echo e(route('assignments',$assignment->subject->id)); ?>" class="nav-link p-2 border"><?php echo e($assignment->assignment_name); ?></a>
                        </span>
                    </li>
                    <li class="nav-item mt-2">
                        <span class="mx-2 p-2 border">
                            <b>Total Marks:</b> X/<?php echo e($assignment->total_points); ?>

                        </span>
                    </li>
                    <li class="nav-item mt-2">
                        <span class="mx-2 p-2 border">
                            <b>Total submissions:</b> <?php echo e($assignment->assignment_submissions->count()); ?> out of <?php echo e($assignment->subject->users->count()); ?>

                        </span>
                    </li>
                    <li class="nav-item mt-2">
                        <span class="mx-2 mt-2 p-2 border">
                            <b>Graded:</b> <span class="graded"></span>
                        </span>
                    </li>
                    <li class="nav-item mt-2">
                        <span class="mx-2 p-2 border">
                            <select name="submitted_users" id="submission_list" class="custom-input" style='width:200px' onchange="fetchSubmittedAssignment(<?php echo e($assignment->id); ?>,$(this).val())">
                                <option value="" hidden>Select student</option>
                                    <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submitted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($submitted->user->id); ?>"><?php echo e($submitted->user->firstName); ?> <?php echo e($submitted->user->lastName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row p-1">
            <div class="col p-4 shadow bg-white assignment-displayed">
                <embed src="reagan.pdf"><embed>
            </div>
            <div class="col-md-2 p-2 border-left bg-white mx-1">
                <div class="header h4">Assignment Details</div>
                <label for="user-attachments" class="form-label"></label>
                <input type="hidden" name="submission_id" id='submission_id'>
                <select name="" id="user-attachments" class="custom-select" onchange="loadAttachment($(this).val())"></select>

        <!--add grades-->
                <div class="p-2">
                    <div class="header h4">Marks / Grades</div>
                    <input type="text" class="form-control" id="assigned_grade"  onblur="submitGrade($(this).val(),<?php echo e($assignment->total_points); ?>,$('#submission_id').val())" style="width:60px" min='0'>
                </div>
        <!--add comments-->
                <div class="p-2">
                    <div class="header h4">Comments</div>
                    <div class="p-2 submission-comments">
                        
                    </div>
                    <textarea type="text" class="form-control" id="assigned_comment"  cols='20' rows='3'></textarea>
                    <div class="p-1 row">
                        <div class="col p-2">
                            <button class="btn btn-sm btn-primary right" onclick="saveComment($('#assigned_comment').val(),$('#submission_id').val())">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/assignments/grade.blade.php ENDPATH**/ ?>