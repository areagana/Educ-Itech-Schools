
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subject',$subject,Auth::user()->school,Auth::user()->school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="row mx-1">
        <div class="col p-2 bg-white">
            <div class='p-2 subject-card-home bg-white'>
                <h4 class='header'>To-Do</h4>
                <?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 border-light">
                        <?php echo e(dd($upcoming)); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class='p-2 subject-card-home'>
                <h4 class='header'>Recent Activity</h4>
                <?php $__currentLoopData = $previous; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 border border-light m-1">
                        <?php echo e($event->assignment_name); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-2 p-2 bg-white ml-1">
            <div class='header h5'>Upcoming ...</div>
                <div class='p-2'>
                <?php if($upcoming !=''): ?>
                    <?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-2 border border-light">
                            <?php echo e($event->assignment_name); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="p-2">
                        No upcoming events
                    </div>
                <?php endif; ?>
                </div>
            <div class='header h5'>Past Events</div>
                    <div class='p-2'>
                    <?php if($previous !=''): ?>
                        <?php $__currentLoopData = $previous; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-2">
                                <?php echo e($event->assignment_name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="p-2">
                            No ended events
                        </div>
                    <?php endif; ?>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/view.blade.php ENDPATH**/ ?>