
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <div class="card p-2 border-primary">
                    <h5 class="p-2 border-primary border-bottom ">Enroll students to <?php echo e($form->form_name); ?>

                        <span class="right">
                            <input type="text" id="searchSTudent"  class='form-control form-control-sm' onkeyup="SearchItem('searchSTudent','enroll-form-students','tr')" placeholder="Search...">
                        </span>
                    </h5>
                    <form action="<?php echo e(route('enrollStudents')); ?>" method='POST' id='enroll-students-form'>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="form_id" value="<?php echo e($form->id); ?>">
                    <table class="table table-sm">
                        <thead class="table-info">
                            <th>
                                <input type="checkbox" name="select_all" id="select_all" onclick="selectAll('selected_student')">
                            </th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('firstName', 'First Name'));?></th>
                            <td><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('lastName', 'Last Name'));?></td>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', 'User_id'));?></th>
                        </thead>
                        <tbody id='enroll-form-students'>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected_student[]" id="selected_student<?php echo e($student->id); ?>" value="<?php echo e($student->id); ?>">
                                    </td>
                                    <td><label for="selected_student<?php echo e($student->id); ?>"><?php echo e($student->firstName); ?></label></td>
                                    <td><?php echo e($student->lastName); ?></td>
                                    <td><?php echo e($student->id); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </form>
                    <div class="row p-2">
                        <div class="col">
                            <?php echo $students->appends(Request::except('page'))->render(); ?>

                        </div>
                        <div class="col p-1">
                            <span class="right">Displaying <?php echo e($students->count()); ?> of <?php echo e($students->total()); ?></span> 
                        </div>
                    </div>
                    <div class="row p-2">
                        <div class="col p-2">
                            <button class="btn btn-primary btn-sm right" type='submit' form="enroll-students-form">Enroll in <?php echo e($form->form_name); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\forms\enroll.blade.php ENDPATH**/ ?>