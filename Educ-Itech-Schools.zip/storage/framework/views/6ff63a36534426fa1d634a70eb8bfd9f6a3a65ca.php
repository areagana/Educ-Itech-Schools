
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('assignment.show',$subject,$assignment,$subject->id,$assignment->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <h2>
            Waaoooohhh!! <br>
            You have successfully submitted your assignment
        </h2>

        <div class="p-2">
            <h4 class="header">Details</h4>
            Attachments: <?php echo e(count($files)); ?>

            Assignment Names:<?php echo e(dd($files)); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\subjects\assignments\submitted.blade.php ENDPATH**/ ?>