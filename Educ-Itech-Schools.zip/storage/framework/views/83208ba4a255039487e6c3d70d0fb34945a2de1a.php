
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schools')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <h3 class="header p-3">LIST OF SCHOOLS
                    <span class="right h6">
                        <a href="<?php echo e(route('newSchool')); ?>" class="nav-link btn btn-secondary btn-sm"  data-tippy="Add School" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><i class="fa fa-plus"></i> SCHOOL</a>
                    </span>
                </h3>
            </div>
        </div>
        <div class="row p-2">
            <div class="col p-2 inline-block">
                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('schoolView',$school->id)); ?>" class="nav-link">
                            <div class="school-card p-2 shadow-sm bg-white mx-2">
                                <h5 class='p-1 text-dark'><i class="fa fa-school"></i> <?php echo e($school->school_name); ?></h5>
                                <div class="p-0 border-top">
                                    <a href="#" class="nav-link"><i class="fa fa-users"> Accounts: (<?php echo e($school->users->count()); ?>)</i></a>
                                    <a href="#" class="nav-link"><i class="fa fa-book"> Courses: (<?php echo e($school->courses->count('course_name')); ?>)</i></a>
                                    <a href="#" class="nav-link"><i class="fa fa-user"> Students:</i></a>
                                    <a href="#" class="nav-link"><i class="fa fa-users"> Subjects: (<?php echo e($school->subjects->count()); ?>)</i></a>
                                    <a href="#" class="nav-link"><i class="fa fa-users"> Cls (<?php echo e($school->forms->count('form_name')); ?>)</i></a>
                                    <a href="#" class="nav-link"><i class="fa fa-users"> Cls (<?php echo e($school->forms->count('form_name')); ?>)</i></a>
                                </div>
                                <div class="p-2 border-top">
                                    Created: <?php echo e(date('M/y')); ?>

                                    <span class="right"><i class="fa fa-ellipsis-v btn btn-sm btn-circle btn-light"  data-tippy="More" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" onclick="ShowMore('school_more<?php echo e($school->id); ?>')"></i>
                                    </span>
                                    <div class="more absolute more-for-schools" id="school_more<?php echo e($school->id); ?>">
                                            <a href="<?php echo e(route('schoolEdit',$school->id)); ?>" class="nav-link"><i class="fa fa-edit"></i> Edit</a>
                                            <a href="" class="nav-link"><i class="fa fa-trash"></i> Delete</a>
                                        </div>
                                        
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/show.blade.php ENDPATH**/ ?>