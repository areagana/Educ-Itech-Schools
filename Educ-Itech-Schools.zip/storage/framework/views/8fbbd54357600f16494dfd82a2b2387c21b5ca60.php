

<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('assignment.show',$subject,$assignment,$subject->id,$assignment->id)); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <div class="row p-1">
            <div class="col-md-9 p-2 bg-white">
                <h3 class='header'><?php echo e($assignment->assignment_name); ?>

                    <?php if(Auth::user()->hasRole(['teacher','ict-admin','admininistrator','superadministrator'])): ?>
                    <span class="right h5 inline-block">
                        <i class="fa fa-edit btn btn-light"> Edit</i> 
                        <i class="fa fa-trash btn btn-light" onclick="xdialog.confirm('Confirm to delete this assignment?',function(){deleteItem(<?php echo e($assignment->id); ?>,'/assignment/delete')})"> Delete</i>
                    </span>
                    <?php endif; ?>
                </h3>
                <div class="p-2">
                    <?php echo $assignment->assignment_content; ?><br>
                    <!--show assignment attachment-->
                    <?php if($assignment->assignment_attachment): ?>
                        <div class="p-2">
                            <h5 class="header">Attachment</h5>
                            <a href="<?php echo e(route('DownloadAssignment',$assignment->id)); ?>" class="nav-link">
                                <?php echo e($assignment->assignment_attachment); ?>

                                <span class="right bg-success p-2 text-white"><i class="fa fa-download"></i> Download</span>
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="row p-2">
                        <div class="col p-2 text-muted border-top">
                            <div class="p-2">
                                <?php if($assignment->close_date >= date('Y-m-d')): ?>
                                        <b><?php echo e(__('Upcoming')); ?></b> <br>
                                        Submission Deadline: <span class="right"><?php echo e(dateFormat($assignment->close_date,'D jS M Y')); ?> at <?php echo e(dateFormat($assignment->close_date,'H:m')); ?>Hrs</span>
                                <?php else: ?>
                                    <b><?php echo e(__('Ended')); ?> </b><br>
                                    closed on <?php echo e($assignment->close_date); ?>

                                <?php endif; ?>
                            </div>
                            <?php if(Auth::user()->hasRole(['teacher','administrator','ict-admin','school-administrator','superadministrator'])): ?>
                            <div class="p-2">
                            <b><?php echo e(__('Submissions')); ?> </b><br>
                                <?php if(count($assignment->assignment_submissions) > 0): ?>
                                    <?php echo e(count($assignment->assignment_submissions)); ?> submitted
                                    <a href="<?php echo e(route('gradeAssignment',$assignment->id)); ?>" class="nav-link">
                                        <span class="right p-2 bg-info text-white">
                                            Grade submimissions
                                        </span>
                                    </a>
                                <?php else: ?>
                                    No submissions yet
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row p-2">
                    <div class="col p-1">
        <!-- enable this for students-->
                   <?php if(Auth::user()->hasRole(['student','ict-admin','admininistrator','superadministrator'])): ?>
                        <?php if(Auth::user()->assignment_submissions->where('assignment_id',$assignment->id)->count() == 0): ?>
                        <a href="<?php echo e(route('assignment.attempt',[$subject->id,$assignment->id])); ?>" class="nav-link">
                            <button class="btn btn-primary btn-sm right">Attempt Assignment</button>
                        </a>
                        <?php else: ?> 
                            <span class="right p-2 bg-info text-white"> Already submitted</span>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col p-2 mx-1 bg-white">
                <h4 class="border-bottom p-2">To Do</h4>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $subj->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($assigned->end_date > date('Y-m-d')) AND (Auth::user()->assignment_submissions->where('assignment_id',$assigned->id)->count()==0)): ?>
                            <div class="p-2">
                                <?php echo e($assigned->assignment_title); ?>

                            </div>
                        <?php elseif($assigned->end_date < date('Y-m-d')): ?>
                            <div class="p-2">
                                <?php echo e($assigned->assignment_title); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <span class="p-2 bg-light">
                    Incomplete information
                </span>
            </div>
        </div>
        <div class="row p-1">
            <div class="col p-2">
                

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/assignments/show.blade.php ENDPATH**/ ?>