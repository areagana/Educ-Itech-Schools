
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjects',$course,$course->school,$course->school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <h3 class="header">SUBJECTS</h3>
            </div>
        </div>
        <div class="row">
            <div class="col p-2">
                <form action="<?php echo e(route('subjectStore')); ?>" method='POST' id="class_subject_form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row p-2">
                        <input type="hidden" name='term_id' value='1'>
                        <input type="hidden" name='course_id' value="<?php echo e($course->id); ?>">
                        <div class="col p-1">
                            <label for="class_name" class="form-label">Class Name:</label>
                        </div>
                        <div class="col-md-8 p-2">
                           <select name="class_id" id="" class="custom-input p-2">
                               <option value="" hidden>Select</option>
                               <?php $__currentLoopData = $course->school->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($form->id); ?>"><?php echo e($form->form_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
                    </div>
                    <div class="form-group row p-2">
                        <div class="col p-1">
                            <label for="subject_name" class="form-label">Subject Name:</label>
                        </div>
                        <div class="col-md-8 p-2">
                            <input type="text" id='subject_name' name='subject_name' value="<?php echo e($course->course_name); ?>" class="custom-input p-2" >
                        </div>
                    </div>
                    <div class="form-group row p-2">
                        <div class="col p-1">
                            <label for="subject_code" class="form-label"> Subject Code:</label>
                        </div>
                        <div class="col-md-8 p-2">
                            <input type="text" id='subject_code' name='subject_code' class="custom-input p-2" >
                        </div>
                    </div>
                    <div class="form-group row p-2">
                        <div class="col p-1">
                            <button class="btn btn-sm btn-primary right" type='submit'>Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-3 p-2 border-left">
                <div class="h4 header">Active subjects</div>
                <?php $__currentLoopData = $course->school->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class='nav-item'><?php echo e($subject->subject_code); ?>  <?php echo e($subject->subject_name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\subjects\create.blade.php ENDPATH**/ ?>