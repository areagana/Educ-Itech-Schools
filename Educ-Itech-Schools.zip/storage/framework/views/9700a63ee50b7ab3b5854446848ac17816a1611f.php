
<?php $__env->startSection('details'); ?>
    <div class="container-fluid bg-white">
        <div class="h5 border-bottom p-3">FORMS / CLASSES
            <span class="right bg-info p-2 h6"  data-tippy="Add form" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" onclick="ShowDiv('new-form')">
                <i class="fa fa-plus"></i> Form
            </span>
        </div>
        <div class="row p-2">
            <div class="col p-2">
                <table class="table table-sm">
                    <thead class="table-info">
                        <tr>
                            <th>#</th>
                            <th>code</th>
                            <th>Name</th>
                            <th>Members</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $school->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><a href="<?php echo e(route('formView',$form->id)); ?>" class="nav-link"><?php echo e($form->form_code); ?></a></td>
                            <td><a href="<?php echo e(route('formView',$form->id)); ?>" class="nav-link"><?php echo e($form->form_name); ?></a></td>
                            <td><?php echo e(count($form->users)); ?></td>
                            <td>
                                <span class="inline-block">
                                    <a href="<?php echo e(route('FormEnroll',$form->id)); ?>" class="nav-link"><i class="fa fa-plus-circle"  data-tippy="Add Users" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='Add Students'></i></a>
                                    <?php if(Auth::user()->isAbleTo('form-edit')): ?>
                                        <a href="#" class="nav-link"><i class="fa fa-edit"  data-tippy="Edit" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"></i></a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->isAbleTo('form-delete')): ?>
                                        <a href="#" class="nav-link"><i class="fa fa-trash"  data-tippy="Delete" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"></i></a>
                                    <?php endif; ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-6 p-2 border-left hidden new-form">
                <form action="<?php echo e(route('formStore')); ?>" method='POST' id="new-classes-form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row p-2">
                        <input type="hidden" name='school_id' value="<?php echo e($school->id); ?>">
                        <div class="col-md-3 p-2">
                            <label for="class_name" class="form-label">Class Name</label>
                        </div>
                        <div class="col p-2">
                            <input type="text" class="custom-input" name='class_name' id='class_name' autocomplete='off'>
                        </div>
                    </div>
                    <div class="form-group row p-2">
                        <div class="col-md-3 p-2">
                            <label for="class_code" class="form-label">Class Code</label>
                        </div>
                        <div class="col p-2">
                            <input type="text" class="custom-input" name='class_code' id='class_code' autocomplete='off'>
                        </div>
                    </div>
                    <div class="row p-2">
                        <div class="col p-2">
                            <button class="button btn btn-sm btn-primary right" type='submit' form='new-classes-form'>Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/forms/index.blade.php ENDPATH**/ ?>