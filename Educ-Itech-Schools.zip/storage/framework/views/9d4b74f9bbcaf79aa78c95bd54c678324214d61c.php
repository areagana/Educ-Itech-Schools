
<?php $__env->startSection('crumbs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('schoolContent'); ?>
    <div class="row p-2">
        <div class="col p-2 m-2 bg-white">
            Form: <?php echo e($form->form_name); ?> <br>
            Code: <?php echo e($form->form_code); ?> <br>
            School: <?php echo e($school->school_name); ?> <br>
        </div>
        <div class="col p-2 bg-white m-2">
            Students: <?php echo e($form->users->count()); ?> <br>
            Teachers:  <?php echo e($form->users->count()); ?> <br>
            Subjects:  <?php echo e($form->subjects->count()); ?> <br>
        </div>
    </div>
    <div class="row p-2 ">
        <div class="col p-3 bg-white m-2">
            <h4>Assignments</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Notes</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Schemes</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
    </div>
    <div class="row p-2 ">
        <div class="col p-3 bg-white m-2">
            <h4>Exams</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Time Tables</h4>
            Given: <?php echo e($form->timetables->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Conferences</h4>
            Given: <?php echo e($form->conferences->count()); ?> <br>
            Submitted: 
        </div>
    </div>
    <div class="row p-2 ">
        <div class="col p-3 bg-white m-2">
            <h4>Notices</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Notes</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
        <div class="col p-3 bg-white m-2">
            <h4>Schemes</h4>
            Given: <?php echo e($form->assignments->count()); ?> <br>
            Submitted: 
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/forms/view.blade.php ENDPATH**/ ?>