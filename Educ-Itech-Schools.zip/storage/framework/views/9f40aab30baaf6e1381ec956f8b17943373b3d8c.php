
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('userSubjects')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-2 border-bottom">
                <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">
                    <?php echo e($subject->subject_name); ?>

                    <span class="right text-muted">
                        <?php echo e($subject->term['term_name']); ?>/<?php echo e($subject->term['term_year']); ?>

                    </span>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\subjects\show.blade.php ENDPATH**/ ?>