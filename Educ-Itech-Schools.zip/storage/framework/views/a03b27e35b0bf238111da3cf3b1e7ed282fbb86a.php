
<?php $__env->startSection('details'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <div class="card p-2">
                    <div class="h4 bg-info border-bottom border-primary p-2"><?php echo e($subject->subject_name); ?> <i class="fa fa-angle-right h5"></i> members
                        <span class="right">
                            <input type="text" class="form-control form-control-sm" id='searchSubjectMember' placeholder='Search...'  onkeyup="SearchItem('searchSubjectMember','subject_members','tr')">
                        </span>
                    </div>
                    <table class="table table-sm">
                        <thead class="table-info">
                            <tr>
                                <th>
                                    <input type="checkbox" name="select_all" id="select_all" onclick="selectAll('selected_student')">
                                </th>
                                <th>Name</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id='subject_members'>
                            <?php $__currentLoopData = $subject->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input type="checkbox" name="selected_student[]" id="selected_student<?php echo e($member->id); ?>" value="<?php echo e($member->id); ?>"></td>
                                    <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                                    <td><i class="fa fa-trash"></i></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('schools.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\subjects\members.blade.php ENDPATH**/ ?>