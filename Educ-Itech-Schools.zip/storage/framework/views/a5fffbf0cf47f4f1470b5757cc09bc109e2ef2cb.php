
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!--generate user subjects-->
        <div class="row p-2">
            <div class="col">
                <div class="p-2 inline-block">
                    <?php if(!empty($subjects)): ?>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-2 card shadow-sm bg-white justify-content-center m-2">
                            <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">
                                <div class="p-2">
                                    <div class="p-2 justify-content-center">
                                        <h3><?php echo e($subject->subject_name); ?>

                                            
                                        </h3>
                                        <h6 class="text-muted">
                                            <?php echo e($subject->form->form_name); ?>

                                        </h6>
                                    </div>
                                    <div class="p-2">
                                        <?php echo e($subject->subject_code); ?>  
                                    </div>
                                </div>
                            </a>
                            <div class="row p-2">
                                <div class="col p-2 border-top">
                                <span class="right">
                                    <i class="fa fa-ellipsis-v btn btn-sm btn-circle btn-light ellipsis"></i>
                                </span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="p-3 border border-primary">
                            No school term set.
                            Your subjects will appear when the school term setup is complete.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3 p-2 border-left">
                <?php if(!$term): ?>
                    <div class="header p-2 h5">
                        PREVIOUR SUBJECTS
                    </div>
                    <?php $__currentLoopData = Auth::user()->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('subject',$previous->id)); ?>" class="nav-link">
                        <div class="p-2">
                            <?php echo e($previous->subject_code); ?>

                            <span class="right text-muted">
                                <?php echo e($previous->term->term_name); ?> <?php echo e($previous->term->term_year); ?>

                            </span>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/dashboard/index.blade.php ENDPATH**/ ?>