
<?php $__env->startSection('homeContent'); ?>
    <div class="container">
        Clients
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/clients.blade.php ENDPATH**/ ?>