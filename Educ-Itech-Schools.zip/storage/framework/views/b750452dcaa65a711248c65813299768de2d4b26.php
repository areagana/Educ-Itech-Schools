
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schools')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2">
                <h3 class="header p-3">LIST OF SCHOOLS
                    <span class="right h6">
                        <a href="<?php echo e(route('newSchool')); ?>" class="nav-link btn btn-secondary btn-sm"  data-tippy="Add School" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><i class="fa fa-plus"></i> SCHOOL</a>
                    </span>
                </h3>
            </div>
        </div>
        <div class="row p-2">
            <div class="col p-2 bg-white shadow-sm">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>School Name</th>
                            <th>Courses</th>
                            <th>Forms</th>
                            <th>Users</th>
                            <th>More</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sno=1;  ?>
                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class='school-info'>
                                <td><?php echo e($sno++); ?></td>
                                <td><?php echo e($school->school_name); ?></td>
                                <td><?php echo e($school->courses->count('course_name')); ?></td>
                                <td><?php echo e($school->forms->count('form_name')); ?></td>
                                <td><?php echo e($school->users->count()); ?></td>
                                <td>
                                    <a href="" class="nav-link"><i class="fa fa-book hidden hidden-icons" title='courses'></i></a>
                                    <a href="" class="nav-link"><i class="fa fa-address-card hidden hidden-icons" title='courses'></i></a>
                                </td>
                                <td>
                                    <span class="">
                                        <button class="btn btn-sm btn-light btn-circle btn-sm" onclick="ShowMore('school_more<?php echo e($school->id); ?>')"><i class="fa fa-ellipsis-v"></i></button>
                                        <div class="more absolute more-for-schools" id="school_more<?php echo e($school->id); ?>">
                                            <a href="<?php echo e(route('schoolEdit',$school->id)); ?>" class="nav-link"><i class="fa fa-edit"></i> Edit</a>
                                            <a href="<?php echo e(route('schoolView',$school->id)); ?>" class="nav-link"><i class="fa fa-eye"></i> View</a>
                                            <a href="" class="nav-link"><i class="fa fa-trash"></i> Delete</a>
                                        </div>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\schools\show.blade.php ENDPATH**/ ?>