<style>
    table{
        width:100%;
    }
    .table-info{
        background-color:lightblue;
    }
    table,th,tr,td{
        border-collapse:collapse;
        border:1px solid lightgrey;
    }
    tr,th,td{
        padding:2px;
        text-align:center;
    }
    .header{
        border-bottom:1px solid lightgrey;
        padding:3px;
        width:100%;
    }
    .mx-1{
        margin:1px;
    }
    .p-2{
        padding:2px;
    }
    .p-3{
        padding:3px;
    }
    .table-bordered{
        border:1px solid lightgrey;
    }
    .subject-td{
        text-align:left;
    }
</style>

    <div class="row p-0 mx-1">
        <div class="col p-2 bg-white">
                <div class="p-0" id="student-reportcar">
                    <div class="row p-3">
                        <div class="col p-2 header">
                            <?php echo e($school->school_name); ?>

                        </div>
                        <div class="col p-1">
                            Name: <?php echo e($user->firstName); ?> <?php echo e($user->lastName); ?> <br>
                            Gender: <br>
                            Class: <?php echo e($form->form_name); ?> 
                        </div>
                    </div>
                    <table class="table table-sm table-bordered">
                        <thead class="table-info">
                            <tr>
                                <th>Subject</th>
                                <th>Assignments</th>
                                <th>Grade</th>
                                <th>Progress</th>
                                <th>Initial</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total_marks = $subject->assignments->average('total_points');
                                    if($total_marks ==0)
                                    {
                                        $total_marks =1;
                                    }
                                ?>
                                <tr>
                                    <td class='subject-td'><?php echo e($subject->subject_name); ?></td>
                                    <td><?php echo e($subject->assignments->count()); ?></td>
                                    <td><?php echo e(number_format($subject->assignment_submissions()->where('assignment_submissions.user_id',$user->id)->average('submitted_grade') / $total_marks * 100,0)); ?>%</td>
                                    <td>
                                        <?php echo e($subject->assignment_submissions()->where('assignment_submissions.user_id',$user->id)->count()); ?> / <?php echo e($subject->assignments->count()); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $subject->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($member->hasRole('teacher')): ?>
                                                <?php echo e($member->firstName[0]); ?>.<?php echo e($member->lastName[0]); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/reports/PDFStudent.blade.php ENDPATH**/ ?>