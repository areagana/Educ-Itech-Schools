
<?php $__env->startSection('homeContent'); ?>
    <div class="container">
        services
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/services.blade.php ENDPATH**/ ?>