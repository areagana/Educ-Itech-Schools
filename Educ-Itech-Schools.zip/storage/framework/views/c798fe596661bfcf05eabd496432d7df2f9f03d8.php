
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjectGrades',$subject,$subject->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2 bg-white">
                <h4 class="header"><?php echo e($subject->subject_name); ?> Grades</h4>
                <table class="table table-sm table-striped">
                    <thead class="table-info">
                        <tr>
                            <th>User Id</th>
                            <th>Name</th>
                            <?php
                                $total_points =[];
                            ?>
                            <?php $__currentLoopData = $subject->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style='width:100px;font-size:10px'><?php echo e($assignment->assignment_name); ?> <br>(<?php echo e($assignment->total_points); ?>)</th>
                                <?php
                                    $total_points[] = $assignment->total_points;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="subject-grades-table">
                        <?php $__currentLoopData = $subject->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--check if member has role of a student-->
                            <?php if($member->hasRole(['student'])): ?>
                                <?php
                                    $total_marks =[];
                                ?>
                                <tr>
                                    <td><?php echo e($member->id); ?></td>
                                    <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                                    <?php $__currentLoopData = $subject->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $submissions = $assignment->assignment_submissions->where('user_id',$member->id);
                                        ?>
                                        <td>
                        <!--check if a user submitted-->
                                        <?php if(count($submissions) >= 1): ?>
                                            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!--check if submission was marked-->
                                                <?php if($sub->submitted_grade != null): ?>
                                                    <?php echo e(number_format($sub->submitted_grade/$assignment->total_points *100)); ?>%
                                                    <?php
                                                        $total_marks[] = $sub->submitted_grade;
                                                    ?>
                                                <?php else: ?>
                                                </i><a href="<?php echo e(route('gradeAssignment',$assignment->id)); ?>" class=""><i class="fa fa-paper-plane" aria-hidden="true"></i> <?php echo e(__('Grade')); ?></a><i>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <span class="text-danger"><?php echo e(__('*missing')); ?></span>
                                        <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php echo e(number_format(array_sum($total_marks)/array_sum($total_points) *100)); ?>%
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/grades/gradebook.blade.php ENDPATH**/ ?>