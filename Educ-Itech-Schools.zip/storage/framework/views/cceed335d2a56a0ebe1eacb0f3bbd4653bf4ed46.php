
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('userSubjects')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="header p-2 h4 bg-light">Current Enrollments</div>
        <?php if($subjects): ?>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 border-bottom">
                    <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">
                        <?php echo e($subject->subject_name); ?>

                        <span class="right text-muted">
                            <?php echo e($subject->term['term_name']); ?>/<?php echo e($subject->term['term_year']); ?>

                        </span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="p-2">
                <i>No current enrollments</i>
            </div>
        <?php endif; ?>
        <div class="header p-2 h4">Previous Enrollments</div>
        <?php $__currentLoopData = $previouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-2 border-bottom">
                <a href="<?php echo e(route('subject',$previous->id)); ?>" class="nav-link">
                        <?php echo e($previous->subject_name); ?>

                    <span class="right text-muted">
                        <?php echo e($previous->term['term_name']); ?>/<?php echo e($previous->term['term_year']); ?>

                    </span>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/show.blade.php ENDPATH**/ ?>