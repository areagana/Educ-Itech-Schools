
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('schoolView',$school,$school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="p-2 bg-white border-left right more-functions ml-2">
        <a href="" class="nav-link">Add new Students</a>
        <a href="<?php echo e(route('schoolStudents',$school->id)); ?>" class="nav-link">School Students</a>
        <a href="<?php echo e(route('SchoolTeachers',$school->id)); ?>" class="nav-link">Teachers</a>
        <a href="" class="nav-link">Enroll in Subject</a>
        <a href="" class="nav-link">Student Information</a>
        <a href="" class="nav-link">Teacher Information</a>
        <a href="<?php echo e(route('schoolCourses',$school->id)); ?>" class="nav-link">School Courses</a>
        <a href="<?php echo e(route('schoolUsers',$school->id)); ?>" class="nav-link">School Users</a>
        <a href="<?php echo e(route('schoolTerms',$school->id)); ?>" class="nav-link">School Terms</a>
        <a href="<?php echo e(route('schoolForms',$school->id)); ?>" class="nav-link">School Forms</a>
        <a href="<?php echo e(route('schoolSubjects',$school->id)); ?>" class="nav-link">School Subjects</a>
    </div>
    <div class="row p-2">
        <div class="col p-2">
            <h3 class="header p-2"><?php echo e($school->school_name); ?></h3>
        </div>
    </div>
    <?php echo $__env->yieldContent('details'); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\schools\details.blade.php ENDPATH**/ ?>