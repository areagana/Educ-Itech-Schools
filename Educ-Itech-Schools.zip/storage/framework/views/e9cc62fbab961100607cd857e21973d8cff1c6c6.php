
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subjectNotes',$subject,$subject->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col p-2 bg-white shadow-sm">
                <h4><?php echo e($subject->subject_name); ?> Modules / Notes </h4>
            </div>
            <?php if(Auth::user()->hasRole('teacher')): ?>
                <div class="col-md-2 p-2 bg-white shadow-sm">
                    <span class="right p-2 bg-info h6"  data-tippy="Create Module" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><a class='nav-link text-white' href="<?php echo e(route('module',$subject->id)); ?>"><i class="fa fa-plus"></i> Module</a></span>
                </div>
            <?php endif; ?>
        </div>
        <div class="row p-1">
            <div class="col p-2 bg-white shadow-sm mx-1">
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion m-3 shadow-sm" id="accordion<?php echo e($module->id); ?>">
                    <div class="card">
                        <div class="card-header" id="heading<?php echo e($module->id); ?>">
                            <h4 class="mb-0">
                                <span class='module-header' data-toggle="collapse" data-target="#collapse<?php echo e($module->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($module->id); ?>">
                                    <?php echo e($module->module_name); ?>

                                </span>
                                <span class="right">
                                    <div class="dropdown">
                                        <?php if(Auth::user()->hasRole(['teacher','administrator','superadministrator','ict-admin','school-administrator'])): ?>
                                            <button class="btn btn-light dropdown-toggle border border-primary" id="addModuleContent" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-plus m-1"></i></button>
                                            <button class="btn btn-light border border-primary btn-outline-primary" onclick="xdialog.confirm('Do you confirm to delete <?php echo e($module->module_name); ?>? <br> Please note that all the notes with in will be deleted!!',function(){deleteItem('<?php echo e($module->id); ?>','/module/delete')})"  data-tippy="Delete Module" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward"><i class="fa fa-trash"></i></button>
                                        <?php endif; ?>
                                        <button class="btn btn-light" onclick="ShowMore('moreModule<?php echo e($module->id); ?>')"><i class="fa fa-ellipsis-v"></i></button>
                                            <ul class="dropdown-menu text-small shadow p-2" aria-labelledby="addModuleContent">
                                                <li><a class="dropdown-item" href="#" data-toggle='modal' data-target='#notesModule<?php echo e($module->id); ?>'>Text Content</a></li>
                                                <li><a class="dropdown-item" href="#" onclick="ShowDiv('uploadNotes<?php echo e($module->id); ?>')"><i class="fa fa-upload"></i> Upload </a></li>
                                            </ul>
                                    <!--more toggle-->
                                            <div class="more absolute shadow p-2" id='moreModule<?php echo e($module->id); ?>'>
                                                <a href="#" class="nav-link" id='primary' onclick="ModuleColor($(this).attr('id'),<?php echo e($module->id); ?>)">Blue</a>
                                                <a href="#" class="nav-link" id='success' onclick="ModuleColor($(this).attr('id'),<?php echo e($module->id); ?>)">Green</a>
                                                <a href="#" class="nav-link" id='purple' onclick="ModuleColor($(this).attr('id'),<?php echo e($module->id); ?>)">Purple</a>
                                            </div>
                                        </div>
                            <!-- Modal -->
                                    <div class="modal fade" id="notesModule<?php echo e($module->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="staticBackdropLabel"><?php echo e($module->module_name); ?> Text Notes</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="p-2">
                                                        <form action="<?php echo e(route('NoteStore')); ?>" id="moduleContent<?php echo e($module->id); ?>" method='POST'>
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                                                <input type="hidden" name="module_id" value="<?php echo e($module->id); ?>">
                                                                <label for="note_title" class="form-label">Note Title</label>
                                                                <input type="text" name="note_title" id="note_title" class="form-control" placeholder='Title...' required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="textarea" class="form-label">Content</label>
                                                                <textarea type="text" name="note_content" id="textarea<?php echo e($module->id); ?>" class="form-control" required></textarea>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                                                    <button class="btn btn-primary btn-sm" type='submit' form="moduleContent<?php echo e($module->id); ?>">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <!-- end modal-->
                                </span>
                            </h4>
                        </div>
                        <div id="collapse<?php echo e($module->id); ?>" class="collapse show" aria-labelledby="heading<?php echo e($module->id); ?>" data-parent="#accordion<?php echo e($module->id); ?>">
                        <div class="card-body">
                            <div class="p-2 uploadNotes<?php echo e($module->id); ?> hidden shadow note-card note-card-<?php echo e($module->background_color); ?>">
                                <h5 class="header"><b>Upload Module Notes</b></h5>
                                <form action="<?php echo e(route('NoteStore')); ?>" id="module-upload<?php echo e($module->id); ?>" method='POST' enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                        <input type="hidden" name="module_id" value="<?php echo e($module->id); ?>">

                                        <label for="document_title" class="form-label">Document Title</label>
                                        <input type="text" name ='note_title' class="form-control" id="document_title" placeholder='Type title...' autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <label for="document_file" class="form-label">Attachment</label>
                                        <input type="file" name ='file' class="form-control" id="document_file" required>
                                    </div>
                                </form>
                                    <div class="row p-2">
                                        <div class="col p-2">
                                            <button class="btn btn-sm btn-danger" onclick="Close('uploadNotes<?php echo e($module->id); ?>')">Cancel</button>
                                            <button class="btn btn-sm btn-primary right" type='submit' form="module-upload<?php echo e($module->id); ?>">Upload</button>
                                        </div>
                                    </div>
                            </div>
                            <?php if($module->notes->count()>0): ?>
                                <?php $__currentLoopData = $module->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="note-card note-card-<?php echo e($module->background_color); ?> mt-1 row p-2 mx-1">
                                        <div class="p-2 col">
                                            <?php if($note->attachment_name !=''): ?>
                                                <?php echo e($note->note_title); ?>

                                                    <span class="right">
                                                        <i class="fa fa-paperclip btn btn-sm btn-light"  data-tippy="Attachment" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='Attachment'></i>
                                                    </span><br>
                                            <?php else: ?>
                                                <?php echo e($note->note_title); ?> <br>
                                            <?php endif; ?>
                                            <div class="text-muted">
                                                Created: <?php echo e(dateFormat($note->created_at,'jS M Y')); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-2 p-2 border-left  inline-block">
                                            <?php if($note->attachment_name !=''): ?>
                                                <a href="<?php echo e(route('downloadNotes',$note->id)); ?>" class="btn btn-sm btn-<?php echo e($module->background_color); ?>"  data-tippy="Download" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='Download'>
                                                    <i class="fa fa-download"></i>
                                                </a >
                                                <a href="<?php echo e(route('openNotes',$note->id)); ?>" class="btn btn-sm btn-<?php echo e($module->background_color); ?>"  data-tippy="View" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='View' target=_blank>
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('noteView',$note->id)); ?>" class="btn btn-sm btn-<?php echo e($module->background_color); ?>"  data-tippy="View" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='View'>
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->hasRole(['teacher','school-administrator','ict-admin'])): ?>
                                                <a href="#" class="btn btn-sm btn-<?php echo e($module->background_color); ?>"  data-tippy="View" data-tippy-arrow="true" data-tippy-distance="2" data-tippy-animation="shift-toward" title='Delete' 
                                                    onclick="xdialog.confirm('Confirm to delete this note?',function(){deleteItem(<?php echo e($note->id); ?>,'/note/delete')})"><i class="fa fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="p-3 border border-light">
                                    No notes added
                                </div>
                            <?php endif; ?>
                        </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($newmodule) AND $newmodule =='Create'): ?>
                <div class="accordion m-3" id="accordionNewModule">
                    <div class="card">
                        <div class="card-header" id="headingNewModule">
                            <h4 class="mb-0">
                                <form action="<?php echo e(route('moduleStore',$subject->id)); ?>" id="new-module-form" method='POST'>
                                    <?php echo csrf_field(); ?>
                                    <span  data-toggle="collapse" data-target="#collapseNewModule" aria-expanded="true" aria-controls="collapseNewModule">
                                        <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                        <div class="form-group">
                                            <input type="text" name='module_name' class="form-control" placeholder='Module name...' autofocus required>
                                            <div class="row p-1">
                                                <div class="col p-2">
                                                    <button class="btn btn-sm btn-secondary " type='submit'>Cancel</button>
                                                    <button class="btn btn-sm btn-secondary right" type='submit'>Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </span>
                                </form>
                            </h4>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/notes/index.blade.php ENDPATH**/ ?>