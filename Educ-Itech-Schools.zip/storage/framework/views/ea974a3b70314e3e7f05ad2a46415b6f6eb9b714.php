
<?php $__env->startSection('crumbs'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('schoolContent'); ?>
    <div class="row p-2">
        <div class="col">
            <div class="header h3">Assessments</div>
            <div class="row p-2">
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Exams </div>
                    <div class="p-2 row">
                        <div class="col p-2">
                            <img src="<?php echo e(asset('exams-icon.png')); ?>" width="50px" height="40px" class="rounded-circle">
                        </div>
                        <div class="col p-2 border-left justify-content-center">
                            <span class="h3"><?php echo e($school->exams->count()); ?></span>
                        </div>
                        <div class="col p-2 border-left">
                            <span class="h6">
                                <a href="#" class="nav-link" onclick="ShowDiv('new-exam')"><i class="fa fa-plus-circle"></i></a>
                                <a href="" class="nav-link"><i class="fa fa-eye"></i></a>
                            </span>
                        </div>
                    </div>
                </div>
            <!--new-exam model-->
            <?php if($term): ?>
                <div class="shadow bg-white floating-div new-exam border border-primary position-absolute hidden">
                    <div class="border-bottom h4 p-2"> NEW SCHOOL EXAM
                        <span class="right btn  btn-sm btn-outline-danger" onclick="Close('new-exam')">&times;</span>
                    </div>
                    <div class="p-2">
                        <form action="<?php echo e(route('examStore')); ?>" method ='POST' id="new-exam-form">
                            <?php echo csrf_field(); ?>
                            <div class="row p-1">
                                <div class="col p-2">
                                    <div class="form-group">
                                        <input type="hidden" name="school_id" value="<?php echo e($school->id); ?>">
                                        <input type="hidden" name="term_id" value="<?php echo e($term->id); ?>">
                                        <label for="exam_name" class="form-label">Exam Name</label>
                                        <input type="text" class="custom-input" name ='exam_name' id="exam_name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="exam_classes" class="form-label">Class</label>
                                        <select name="exam_class" id="exam_classes" class="custom-select" required>
                                            <option value="All classes">All Classes</option>
                                            <?php $__currentLoopData = $school->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($form->id); ?>"><?php echo e($form->form_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="start_date" class="form-label">Start Date</label>
                                        <input type="date" name="start_date" id="start_date" class='custom-input' required>
                                    </div>
                                    <div class="form-group">
                                        <label for="end_date" class="form-label">End Date</label>
                                        <input type="date" name="end_date" id="end_date" class='custom-input' required>
                                    </div>
                                    <div class="form-group">
                                        <label for="lock_date" class="form-label">Lock Date (Optional) (<i class='text-danger'>Locks Mark entry</i>)</label>
                                        <input type="date" name="lock_date" id="lock_date" class='custom-input'>
                                    </div>
                                </div>
                                <div class="col-md-2 p-2 border-left">
                                    <div class="form-group">
                                        <label for="total_points" class="form-label">Total Points</label>
                                        <input type="number" name="total_points" id="total_points" class="form-control" required>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" name="add_to_reports" id="add_to_reports" value='1' class="form-check-input" zoom="2%">
                                        <label for="add_to_reports" class="form-check-label">Include on final report</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row p-2">
                                <div class="col p-2">
                                    <button type="submit" class="btn btn-outline-primary right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php else: ?>
                <div class="success-alert-message bg-white shadow border border-success row p-2 position-absolute m-4 hidden">
                    <div class="col-md-1">
                    <img src="<?php echo e(asset('notice-icon.jpg')); ?>" width='40px' height='40px' class='rounded-circle'>
                    </div>
                    <div class="col-md-9 p-2 bg-white message-display">
                        No term has been set yet.
                    </div>
                    <div class="col-md-1 p-2">
                    <button class="close" data-dismiss='alert' onclick="Close('success-alert-message')">&times;</button>
                    </div>
              </div>
                <?php endif; ?>
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Course Works
                    </div>
                    <div class="p-2">
                        <div class="p-2 row">
                            <div class="col p-2">
                                <img src="<?php echo e(asset('exams-icon.png')); ?>" width="50px" height="40px" class="rounded-circle">
                            </div>
                            <div class="col p-2 border-left justify-content-center">
                                <span class="h3"><?php echo e($school->exams->count()); ?></span>
                            </div>
                            <div class="col p-2 border-left">
                                <span class="h6">
                                    <a href="" class="nav-link"><i class="fa fa-plus-circle"></i></a>
                                    <a href="" class="nav-link"><i class="fa fa-eye"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Results</div>
                    <div class="p-2">
                        <div class="p-2 row">
                            <div class="col p-2">
                                <img src="<?php echo e(asset('exams-icon.png')); ?>" width="50px" height="40px" class="rounded-circle">
                            </div>
                            <div class="col p-2 border-left">
                                <span class="h3"><?php echo e($school->exams->count()); ?></span>
                            </div>
                            <div class="col p-2 border-left">
                                <span class="h6">
                                    <a href="" class="nav-link"><i class="fa fa-plus-circle"></i></a>
                                    <a href="" class="nav-link"><i class="fa fa-eye"></i></a>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row p-2">
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Marksheets</div>
                    <div class="p-2">

                    </div>
                </div>
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Grade sheets</div>
                    <div class="p-2">

                    </div>
                </div>
                <div class="col p-2 bg-white m-2">
                    <div class="p-2 h5">Analysis</div>
                    <div class="p-2">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 p-2">
            <h3 class="header bg-white">Exams</h3>
            <?php $__currentLoopData = $school->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 shadow-sm school-exam bg-white mt-1">
                    <?php echo e($exam->exam_name); ?> <br>
                    <span class="text-muted"><?php echo e($exam->term->term_name); ?></span> <br>
                    <span class=" text-muted">
                        <?php if(date($exam->end_date) >= date('Y-m-d')): ?>
                            <i class="text-success right">Runnning..</i> <br>
                            <i>Ends on: <u><?php echo e(dateFormat($exam->end_date,'D jS M y')); ?></u>
                        
                            <span class="right" onclick="xdialog.confirm('Delete this Exam?',function(){deleteItem(<?php echo e($exam->id); ?>,'/exam/delete')})">&times;</span></i>

                        <?php else: ?>
                            <i class="text-danger">Closed</i>
                        <?php endif; ?>
                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/assessments.blade.php ENDPATH**/ ?>