
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('crumbs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('schoolContent'); ?>
    <div class="row p-2">
        <div class="col p-2 bg-white">
            <div class="header h3">Schemes of Work
                <span class="right inline-block h6">
                    <a href="" class="nav-link btn btn-sm btn-outline-success"><i class="fa fa-upload"></i> Upload</a>
                    <a href="" class="nav-link btn btn-sm btn-outline-info"><i class="fa fa-eye"></i> Review</a>
                    <a href="" class="nav-link btn btn-sm btn-outline-primary"><i class="fa fa-print"></i> Print</a>
                </span>
            </div>
        </div>
    </div>
    <div class="row p-2">
        <div class="col p-2 bg-white ">
            <?php if($currentschemes->count() > 0): ?>
            <table class="table table-sm table-hover">
                <thead class="table-info">
                    <tr>
                        <th colspan='7'><span class="text-align-center"><?php echo e($term->term_name); ?> <?php echo e($term->term_year); ?> Schemes of work</span></th>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Course</th>
                        <th>Class</th>
                        <th>Title</th>
                        <th>Attachment</th>
                        <th>D.O.Upload</th>
                        <th>More</th>
                    </tr>
                </thead>
                <tbody id='school-schemes'>
                    <?php if($currentschemes->count() > 0): ?>
                        <?php $__currentLoopData = $currentschemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $scheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($scheme->subject->course->course_name); ?></td>
                                <td><?php echo e($scheme->form->form_name); ?></td>
                                <td><?php echo e($scheme->scheme_title); ?></td>
                                <td><?php echo e($scheme->scheme_attachment); ?></td>
                                <td><?php echo e(dateFormat($scheme->created_at,'D jS M y')); ?></td>
                                <td>
                                    <span class="justify-content-center inline-block">
                                        <a href="<?php echo e(route('viewScheme',$scheme->id)); ?>" class="nav-link btn btn-outline-primary btn-sm" target=_blank><i class="fa fa-eye"></i></a>
                                        <a href="<?php echo e(route('DownloadScheme',$scheme->id)); ?>" class="nav-link btn btn-outline-primary btn-sm"><i class="fa fa-download"></i></a>
                                        <a href="#" class="nav-link btn btn-outline-primary btn-sm" onclick="xdialog.confirm('Confirm to delete <?php echo e($scheme->scheme_title); ?>?',function(){deleteItem(<?php echo e($scheme->id); ?>,'/scheme/delete')})"><i class="fa fa-trash"></i></a>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan='7'><span class='h5'><center><i>No schemes Uploaded for this term</i></center></span></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php else: ?>
        <!--if no schemes for the current term are available-->
                <div class="p-2">
                    <div class="header h4">Schemes</div>
                    <div class="p-2 scheme-previous shadow-sm mt-1">
                        <p>All schemes for this term will be dispayed here after teachers have uploaded.</p>
                        <p>The administrator has a role of giving teachers classes to access and upload content as required by the school.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-md-3 ml-1">
            <div class="header h5 bg-white">Upload pdf Document</div>
            <div class="p-2 bg-white shadow-sm">
                <form action="<?php echo e(route('storeSchemes')); ?>" method='POST' id='timetable-upload-form' enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name="school_id" value='<?php echo e($school->id); ?>'>
                        <input type="hidden" name="term_id" value='<?php echo e($term->id); ?>'>
                        <label for="timetable_title" class="form-label">Title</label>
                        <input type="text" class="form-control form-control-sm" name='scheme_title' id='timetable_title' placeholder="Title..." required>
                    </div>
                    <div class="form-group">
                        <div class="header h6">Class</div>
                        <select name="school_forms" id="school_forms_schemes" class="custom-select custom-select-sm" onchange="loadSubjects($(this).val(),'form_subjects')"required>
                            <option value="" hidden>Select</option>
                            <?php $__currentLoopData = $school->forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($form->id); ?>"><?php echo e($form->form_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="header h6">Subject</div>
                        <select name="form_subjects" id="form_subjects" class="custom-select custom-select-sm" required>
                            <option value="" hidden>Select class first</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="timetable"><i class="fa fa-paperclip"></i> File</label>
                        <input type="file" name="scheme" id="timetable" class='form-control form-control-sm' required>
                        <?php if($errors->has('file')): ?>
                            <span class="errormsg text-danger"><?php echo e($errors->first('file')); ?></span>
                        <?php endif; ?>
                    </div>
                </form>
                <div class="row p-1">
                        <div class="col p-2">
                            <button class="btn btn-sm btn-primary right" form='timetable-upload-form'><i class="fa fa-share"></i> Submit</button>
                        </div>
                </div>
            </div>
            <div class="header bg-white mt-2 h4">Previous schemes</div>
            <div class="header bg-white mt-2 h4"><input type="text" class="form-control form-control-sm" id = 'find_previous' onkeyup="SearchItemClass('find_previous','previous-schemes','scheme-previous')" placeholder='Search...'></div>
            <div class="p-2" id='previous-schemes'>
                <?php if($allSchemes->count() > 0): ?>
                
                    <?php $__currentLoopData = $allSchemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previous): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="p-2 mt-1 bg-white scheme-previous shadow-sm"> 
                            <?php echo e($previous->scheme_title); ?> <span class="right text-muted"><?php echo e($previous->term->term_name); ?></span> <br>
                            <span class="text-muted"><?php echo e($previous->form->form_name); ?> (<?php echo e($previous->subject->subject_name); ?>)
                                <span class="right"><a href="<?php echo e(route('DownloadScheme',$previous->id)); ?>" class="nav-link" title='download'><i class="fa fa-download"></i></a></span>
                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="p-2 mt-1 bg-white scheme-previous shadow-sm"> 
                        <span class="h5"><center><i>No Previous Schemes found</i></center></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/schemes/index.blade.php ENDPATH**/ ?>