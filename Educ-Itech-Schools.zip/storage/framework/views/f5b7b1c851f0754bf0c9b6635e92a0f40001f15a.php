
<?php $__env->startSection('crumbs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="header h4">Time Tables</div>
        <div class="row p-2">
            <div class="col p-2">
            <!-- check if the class has timetables-->
                <?php if(Auth::user()->hasRole(['student'])): ?>
                    <?php
                        $form = Auth::user()->forms->first();
                    ?> 
                    
                <?php endif; ?>
                <?php if($form->timetables()->where('term_id',$term->id)->count() > 0): ?>
                    <?php $__currentLoopData = $form->timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-2 time-table bg-white shadow-sm mt-1">
                            <?php echo e($table->title); ?> 
                            <span class="right inline-block">
                                <a href="<?php echo e(route('DownloadTimetable',$table->id)); ?>" class="nav-link btn btn-outline-danger btn-sm"><i class="fa fa-download"> Download</i></a>
                                <a href="<?php echo e(route('viewTimetable',$table->id)); ?>" class="nav-link btn btn-outline-primary btn-sm" target=_blank ><i class="fa fa-eye"> View</i></a>
                            </span> <br>
                            <span class="text-muted">
                                <?php echo e($table->form->form_name); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--display other genereal timetables if class timetables are found-->
                    <?php if($termTimetables): ?>
                        <?php $__currentLoopData = $termTimetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$ttable->form()->exists()): ?><!-- checks if the relationship has does not have data to avoid repetitions-->
                                <div class="p-2 bg-white time-table shadow-sm mt-1">
                                    <?php echo e($ttable->title); ?>

                                    <span class="right inline-block">
                                        <a href="<?php echo e(route('DownloadTimetable',$ttable->id)); ?>" class="nav-link btn btn-outline-danger btn-sm"><i class="fa fa-download"> Download</i></a>
                                        <a href="<?php echo e(route('viewTimetable',$ttable->id)); ?>" class="nav-link btn btn-outline-primary btn-sm" target=_blank ><i class="fa fa-eye"> View</i></a>
                                    </span> <br>
                                    <span class="text-muted">
                                        <?php echo e(__('All classes')); ?>

                                    </span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php elseif($termTimetables): ?>
                    <?php $__currentLoopData = $termTimetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 bg-white time-table shadow-sm mt-1">
                        <?php echo e($ttable->title); ?>

                        <span class="right inline-block">
                            <a href="<?php echo e(route('DownloadTimetable',$ttable->id)); ?>" class="nav-link btn btn-outline-danger btn-sm"><i class="fa fa-download"> Download</i></a>
                            <a href="<?php echo e(route('viewTimetable',$ttable->id)); ?>" class="nav-link btn btn-outline-primary btn-sm" target=_blank ><i class="fa fa-eye"> View</i></a>
                        </span> <br>
                        <span class="text-muted">
                            <?php echo e(__('All classes')); ?>

                        </span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                <?php else: ?>
                    <div class="p-2 bg-white time-table">
                        <span class="h4">No timetables to show</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/schools/timetables/userView.blade.php ENDPATH**/ ?>