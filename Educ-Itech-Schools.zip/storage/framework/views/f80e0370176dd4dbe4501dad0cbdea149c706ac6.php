
<?php echo $__env->make('includes.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('crumbs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('subjectContent'); ?>
    <div class="row p-1">
        <div class="col">
            <h3 class="header bg-white"><?php echo e($subject->subject_name); ?> / <?php echo e($subject->form->form_name); ?> Assessments
                <span class="right">
                    <button class="btn btn-sm btn-outline-primary">Enter Marks</button>
                    <button class="btn btn-sm btn-outline-primary">Marks</button>
                </span>
            </h3>
            <div class="p-2 row">

                <div class="col p-2 bg-white">
                    <div class="row px-3">
                        <div class="col-md-4 p-2">
                            <select name="" id="filter-subject-members" class="custom-select" onchange="FilterMembers('filter-subject-members',<?php echo e($subject->id); ?>)">
                                <option value="All">All</option>
                                <option value="student">Students</option>
                                <option value="teacher">Teachers</option>
                            </select>
                        </div>
                        <div class="col p-2">
                            <input type="text" class="form-control" id="search-member" onkeyup="SearchItem('search-member','subject-people','tr')" placeholder='Search...'>
                        </div>
                    </div>
                    <div class="row p-2">
                        <div class="col">
                            <table class="table table-sm">
                                <thead class="table-info">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <?php $__currentLoopData = $termExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($exam->examresults()->exists()): ?> <!--check if the relationship has data-->
                                                <th>Exam<?php echo e(++$key); ?> ( /<?php echo e($exam->total_points); ?>)</th>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e(__('Total')); ?></th>
                                        <th><?php echo e(__('Avg')); ?></th>
                                    </tr>
                                </thead>
                                <tbody id='subject-people'>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $tot_marks =[];
                                        ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                                            <?php $__currentLoopData = $termExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($exam->examresults()->exists()): ?> <!--check if the relationship has data-->
                                                    <?php
                                                        $result = $member->examresults()->where('subject_id',$subject->id)->where('exam_id',$exam->id)->get();
                                                        $tot_marks[] = userExamMarks($result)[0];
                                                    ?>
                                                <td><?php echo e(userExamMarks($result)[0]); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e(array_sum($tot_marks)); ?></td>
                                            <td><?php echo e(average($tot_marks)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <h4 class="header bg-white">Exams</h4>
                    <?php $__currentLoopData = $termExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-2 bg-white mt-2 shadow-sm school-exam">
                            <?php echo e($exam->exam_name); ?>

                            <?php if(!$subject->examresults()->exists()): ?>
                                <a href='#' class="right nav-link" onclick="ShowDiv('enter-marks-<?php echo e($exam->id); ?>')"><i class="fa fa-plus-circle"></i> Marks</a>
                            <?php else: ?>
                                <a href='#' class="right nav-link" onclick="ShowDiv('update-marks-<?php echo e($exam->id); ?>')"><i class="fa fa-edit"></i> Marks</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>  
        <?php $__currentLoopData = $termExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="bg-white shadow border border-primary floating-div hidden enter-marks enter-marks-<?php echo e($exam->id); ?> p-0">
            <div class="p-2 bg-info text-white h5">
                Enter Marks (<?php echo e($exam->exam_name); ?>)
                <button  class="right px-2 btn-sm btn btn-danger" onclick="Close('enter-marks-<?php echo e($exam->id); ?>')">&times;</button>
            </div>
            <div class="p-2">
                    <div class="row px-3">
                        <div class="col-md-4 p-2">
                            <select name="" id="filter-subject-members" class="custom-select" onchange="FilterMembers('filter-subject-members',<?php echo e($subject->id); ?>)">
                                <option value="All">All</option>
                                <option value="student">Students</option>
                                <option value="teacher">Teachers</option>
                            </select>
                        </div>
                        <div class="col p-2">
                            <input type="text" class="form-control" id="search-member-res<?php echo e($exam->id); ?>" onkeyup="SearchItem('search-member-res<?php echo e($exam->id); ?>','subject-people-results<?php echo e($exam->id); ?>','tr')" placeholder='Search...'>
                        </div>
                    </div>
                    <div class="row p-1">
                        <form action="<?php echo e(route('markStore')); ?>" id="mark-input-form" method='POST'>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                            <input type="hidden" name="school_id" value="<?php echo e($school->id); ?>">
                            <input type="hidden" name="term_id" value="<?php echo e($term->id); ?>">
                            <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>">
                            <div class="col">
                                <table class="table table-sm">
                                    <thead class="table-info">
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Mark( /<?php echo e($exam->total_points); ?>)</th>
                                            <th>Comment</th>
                                        </tr>
                                    </thead>
                                    <tbody id='subject-people-results<?php echo e($exam->id); ?>'>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                                                <input type="hidden" name="user_id[]" value="<?php echo e($member->id); ?>">
                                                <td><input type="text" name="marks[]" class="form-control form-control-sm mark-input" width="40px"></td>
                                                <td><input type="text" name="comment[]"  class="form-control form-control-sm" placeholder='Comment...'></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row p-2">
                                <div class="col p-2">
                                    <button class="btn btn-primary right" type='submit'>Submit Marks</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>

    <!-- update exam results-->
        <div class="bg-white shadow border border-primary floating-div hidden enter-marks update-marks-<?php echo e($exam->id); ?> p-0">
            <div class="p-2 bg-info text-white h5">
                Enter Marks (<?php echo e($exam->exam_name); ?>)
                <button  class="right px-2 btn-sm btn btn-danger" onclick="Close('update-marks-<?php echo e($exam->id); ?>')">&times;</button>
            </div>
            <div class="p-2">
                    <div class="row px-3">
                        <div class="col-md-4 p-2">
                            <select name="" id="filter-subject-members" class="custom-select" onchange="FilterMembers('filter-subject-members',<?php echo e($subject->id); ?>)">
                                <option value="All">All</option>
                                <option value="student">Students</option>
                                <option value="teacher">Teachers</option>
                            </select>
                        </div>
                        <div class="col p-2">
                            <input type="text" class="form-control" id="search-member-res<?php echo e($exam->id); ?>" onkeyup="SearchItem('search-member-res<?php echo e($exam->id); ?>','subject-people-results<?php echo e($exam->id); ?>','tr')" placeholder='Search...'>
                        </div>
                    </div>
                    <div class="row p-1">
                        <form action="<?php echo e(route('markUpdate')); ?>" id="mark-input-form" method='POST'>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                            <input type="hidden" name="school_id" value="<?php echo e($school->id); ?>">
                            <input type="hidden" name="term_id" value="<?php echo e($term->id); ?>">
                            <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>">
                            <div class="col">
                                <table class="table table-sm">
                                    <thead class="table-info">
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Mark( /<?php echo e($exam->total_points); ?>)</th>
                                            <th>Comment</th>
                                        </tr>
                                    </thead>
                                    <tbody id='subject-people-results<?php echo e($exam->id); ?>'>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $result = $member->examresults()->where('subject_id',$subject->id)->where('exam_id',$exam->id)->get();
                                                        $mark = userExamMarks($result)[0];
                                                        $comment = userExamMarks($result)[1];
                                                    ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                                                <input type="hidden" name="user_id[]" value="<?php echo e($member->id); ?>">
                                                <td><input type="text" name="marks[]" value="<?php echo e($mark); ?>" class="form-control form-control-sm mark-input" width="40px"></td>
                                                <td><input type="text" name="comment[]" value="<?php echo e($comment); ?>" class="form-control form-control-sm" placeholder='Comment...'></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row p-2">
                                <div class="col p-2">
                                    <button class="btn btn-primary right" type='submit'>Submit Marks</button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subjectView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/subjects/assessments/teacher.blade.php ENDPATH**/ ?>