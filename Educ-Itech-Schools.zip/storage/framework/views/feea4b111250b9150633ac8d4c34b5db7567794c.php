
<?php $__env->startSection('crumbs'); ?>
    <?php echo e(Breadcrumbs::render('subject',$subject,Auth::user()->school,Auth::user()->school->id)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-2">
            <div class="col-md-2 p-2 bg-white mt-2 shadow-sm">
                <ul class="nav" style="display:block">
                    <li class="nav-item">
                        <a href="<?php echo e(route('subject',$subject->id)); ?>" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectNotes',$subject->id)); ?>" class="nav-link">Notes</a>
                    </li>
                    <?php if(Auth::user()->hasRole(['teacher'])): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('subjectSchemes',$subject->id)); ?>" class="nav-link">Schemes</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('assignments',$subject->id)); ?>" class="nav-link">Assignments</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectGrades',$subject->id)); ?>" class="nav-link">Grades</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectConferences',$subject->id)); ?>" class="nav-link">Conferences</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectAssessments',$subject->id)); ?>" class="nav-link">Assessments</a>
                     </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectAnnouncements',$subject->id)); ?>" class="nav-link">Announcements</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectMember',$subject->id)); ?>" class="nav-link">Members</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('subjectFiles',$subject->id)); ?>" class="nav-link">Files</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-10 mt-2">
                <?php echo $__env->yieldContent('subjectContent'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views/layouts/subjectView.blade.php ENDPATH**/ ?>