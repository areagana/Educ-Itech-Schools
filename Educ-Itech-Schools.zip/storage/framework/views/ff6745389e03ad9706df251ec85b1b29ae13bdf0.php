<?php

function dateFormat($date,$format)
{
    $date = date_create($date);
    $date = date_format($date,$format);
    return $date;
} ?><?php /**PATH C:\xampp\htdocs\Educ-Itech-Schools\resources\views\includes\functions.blade.php ENDPATH**/ ?>